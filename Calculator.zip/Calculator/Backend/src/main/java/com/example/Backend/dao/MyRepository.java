package com.example.Backend.dao;

public class MyRepository {

}
