package com.example.Backend.controller;
import java.util.Stack;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Backend.entity.MyEntity;
import com.example.Backend.service.MyService;



@RestController
@CrossOrigin
@RequestMapping("/calculator")

public class MyController {
	@Autowired
	public MyService calculatorservice;
	public static int memory=0;
	
   
	@PostMapping("/calculate")
	public String calculate(@RequestBody MyEntity calculator) {
		System.out.println(calculatorservice.evaluate(calculator.getExpression()));
		return ""+calculatorservice.evaluate(calculator.getExpression());
	}
	
	
	@PostMapping("/madd")
	public String madd(@RequestBody MyEntity calculator) {
		System.out.println("Memory saved after addition: " + memory);
		memory = memory + calculator.getMemory();
		return "Memory saved after addition: " + memory;
		
	}
	
	@PostMapping("/msub")
	public String msub(@RequestBody MyEntity calculator) {
		System.out.println("Memory saved after substraction: " + memory);
		memory = memory - calculator.getMemory();
		return "Memory saved after subtraction: " + memory;
	}
	
	
	@GetMapping("/mrecall")
	public String mrecall() {
		System.out.println("Memory recall: " + memory);
		return "" + memory;
		
	}
}
