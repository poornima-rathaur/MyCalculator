package com.example.Backend.service;

public interface MyService {
	public int evaluate(String expression);
	public boolean hasPrecedence(char op1, char op2);
	public int applyOp(char op, int b, int a);
}
