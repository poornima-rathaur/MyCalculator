package com.example.Backend.entity;

public class MyEntity {
private String expression;
private int memory;
	

	public String getExpression() {
		return expression;
	}

	public void setExpression(String expression) {
		this.expression = expression;
	}

	public MyEntity(String expression, int memory) {
		super();
		this.expression = expression;
		this.memory= memory;
	}

	public MyEntity() {
		super();
		
	}

	public int getMemory() {
		return memory;
	}

	public void setMemory(int memory) {
		this.memory = memory;
	}


}
